﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace StatlerAndWaldorf.Models
{
    public class AprioriAlgorithm
    {
        static ArrayList AprioriGen(ArrayList L)
        {
            ArrayList Lk = new ArrayList();    //List to store generated Candidate Itemsets
            Regex r = new Regex(",");
            for (int i = 0; i < L.Count; i++)
            {
                string[] subL1 = r.Split(L[i].ToString());
                for (int j = i + 1; j < L.Count; j++)
                {
                    string[] subL2 = r.Split(L[j].ToString());
                    // Compare two items in L, and set them in temp
                    string temp = L[j].ToString();   //store two key sets
                    for (int m = 0; m < subL1.Length; m++)
                    {
                        bool subL1mInsubL2 = false;
                        for (int n = 0; n < subL2.Length; n++)
                        {
                            if (subL1[m] == subL2[n]) subL1mInsubL2 = true;
                        }
                        if (subL1mInsubL2 == false) temp = temp + "," + subL1[m];
                    }

                    // If temp contains the entry for L in the (itemset size +1)
                    //and the focus is not with the candidates seeking the same items set temp
                    string[] subTemp = r.Split(temp);
                    if (subTemp.Length == subL1.Length + 1)
                    {
                        bool isExists = false;
                        for (int m = 0; m < Lk.Count; m++)
                        {
                            bool isContained = true;
                            for (int n = 0; n < subTemp.Length; n++)
                            {
                                if (!Lk[m].ToString().Contains(subTemp[n])) isContained = false;
                            }
                            if (isContained == true) isExists = true;
                        }
                        if (isExists == false) Lk.Add(temp);
                    }
                }
            }
            return Lk;
        }
    }
}