﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StatlerAndWaldorf.Models
{
    public class PearsonCorrelationAlgo
    {
        private readonly StatlerAndWaldorfContext _context;

        public PearsonCorrelationAlgo(StatlerAndWaldorfContext context)
        {
            _context = context;
        }

        

        public double Execute(int movieId1, int movieId2)
        {
            var movielistRating1 = _context.Reviews.Where(g => g.movieId == movieId1).ToList();
            var movielistRating2 = _context.Reviews.Where(g => g.movieId == movieId2).ToList();
            List<Reviews> shared_items = new List<Reviews>();
            foreach (var item in movielistRating1)
            {
                if (movielistRating2.Where(g => g.userId == item.userId).Count() != 0)
                {
                    shared_items.Add(item);
                }
            }

            if (shared_items.Count == 0)
            {
                // they have nothing in common exit with a zero
                return 0;
            }

            // sum up all the preferences
            double product1_review_sum = 0.00f;
            foreach (var item in shared_items)
            {
                product1_review_sum += movielistRating1.Where(
                    x => x.userId == item.userId).FirstOrDefault().rating;
            }
            double product2_review_sum = 0.00f;
            foreach (var item in shared_items)
            {
                product2_review_sum += movielistRating2.Where(
                    x => x.userId == item.userId).FirstOrDefault().rating;
            }

            // sum up the squares
            double product1_rating = 0f;
            double product2_rating = 0f;
            foreach (var item in shared_items)
            {
                product1_rating += Math.Pow(movielistRating1.Where(
                    x => x.userId == item.userId).FirstOrDefault().rating, 2);

                product2_rating += Math.Pow(movielistRating2.Where(
                    x => x.userId == item.userId).FirstOrDefault().rating, 2);
            }

            //sum up the products
            double critics_sum = 0f;
            foreach (var item in shared_items)
            {
                critics_sum += movielistRating1.Where(
                                   x => x.userId == item.userId).FirstOrDefault().rating *
                               movielistRating2.Where(
                                   x => x.userId == item.userId).FirstOrDefault().rating;
            }
            //calculate pearson score
            double num = critics_sum - (product1_review_sum *
                                        product2_review_sum / shared_items.Count);

            double density = (double)Math.Sqrt((product1_rating -
                                                Math.Pow(product1_review_sum, 2) / shared_items.Count) *
                                               ((product2_rating -
                                                 Math.Pow(product2_review_sum, 2) / shared_items.Count)));

            if (density == 0)
                return 0;

            return num / density;
        }
    }
}

