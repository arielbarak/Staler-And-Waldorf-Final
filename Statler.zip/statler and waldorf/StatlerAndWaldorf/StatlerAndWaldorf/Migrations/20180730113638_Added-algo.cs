﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace StatlerAndWaldorf.Migrations
{
    public partial class Addedalgo : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "PTable",
                columns: table => new
                {
                    MovieId1 = table.Column<int>(nullable: false),
                    PearsonNum = table.Column<double>(nullable: false),
                    MovieId2 = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PTable", x => new { x.MovieId1, x.MovieId2 });
                    table.UniqueConstraint("AK_PTable_MovieId1", x => x.MovieId1);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PTable");
        }
    }
}
