﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace StatlerAndWaldorf.Migrations
{
    public partial class addkey : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropUniqueConstraint(
                name: "AK_PTable_MovieId1",
                table: "PTable");

            migrationBuilder.DropPrimaryKey(
                name: "PK_PTable",
                table: "PTable");

            migrationBuilder.AddColumn<int>(
                name: "Id",
                table: "PTable",
                nullable: false,
                defaultValue: 0)
                .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            migrationBuilder.AddPrimaryKey(
                name: "PK_PTable",
                table: "PTable",
                column: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_PTable",
                table: "PTable");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "PTable");

            migrationBuilder.AddUniqueConstraint(
                name: "AK_PTable_MovieId1",
                table: "PTable",
                column: "MovieId1");

            migrationBuilder.AddPrimaryKey(
                name: "PK_PTable",
                table: "PTable",
                columns: new[] { "MovieId1", "MovieId2" });
        }
    }
}
