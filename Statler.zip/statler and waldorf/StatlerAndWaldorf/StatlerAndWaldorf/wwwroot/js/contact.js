﻿$(function () {
    //document ready
    $(document).ready(function () {
        setGoogleMaps();
    });

    //set google map object
    var map;
    function setGoogleMaps() {
        var myLatLng = { lat: 47.639620, lng: -122.130292 };

        map = new google.maps.Map(document.getElementById('map'), {
            center: myLatLng ,
            zoom: 15
        });

        var marker = new google.maps.Marker({
            position: myLatLng,
            map: map,
            title: 'Microsoft Way!'
        });
    }
});
//-47.639620,-122.130292